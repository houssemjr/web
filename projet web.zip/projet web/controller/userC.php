<?php
	include "../config.php";
	require_once '../model/user.php';

	class UtilisateurC {

        function ajouterUtilisateur($Utilisateur){
            $sql="INSERT INTO users (id ,username, pseudo, email, password,rank,acc_type,contact,champ1,champ2,champ3,champ4,role,description,facebook) 
			VALUES (:id,:username,:pseudo,:email, :password, :rank,:acc_type,:contact,:champ1, :champ2, :champ3,:champ4,:role,:description, :facebook)";
            $db = config::getConnexion();
            try{
                $query = $db->prepare($sql);

                $query->execute([
					'id' => $Utilisateur->getId(),
                    'username' => $Utilisateur->getUsername(),
                    'pseudo' => $Utilisateur->getpseudo(),
                    'email' => $Utilisateur->getEmail(),
					'rank' => $Utilisateur->getrank(),
					'acc_type' => $Utilisateur->getacc_type(),
					'contact' => $Utilisateur->getcontact(),
					'champ1' => $Utilisateur->getchamp1(),
					'champ2' => $Utilisateur->getchamp2(),
					'champ3' => $Utilisateur->getchamp3(),
					'champ4' => $Utilisateur->getchamp4(),
					'role' => $Utilisateur->getrole(),
					'description' => $Utilisateur->getdescription(),
					'facebook' => $Utilisateur->getfb(),
                    'password' => $Utilisateur->getPassword()
                ]);
            }
            catch (Exception $e){
                echo 'Erreur: '.$e->getMessage();
            }
        }


        function afficherUtilisateurs(){
			
			$sql="SELECT * FROM users";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}

		function profile($id){
		
			$query = "SELECT * FROM `users` WHERE `id` = $id";
			$db = config::getConnexion();
			$statement = $db->prepare($query);
			try{		
				$statement->execute();
						$result = $statement->fetchAll();
						

						$filtered_rows = $statement->rowCount();
						if($filtered_rows!=0)
						{
							return $result;
						}
						else
						{
							echo "<script>alert('no table found')</script>";
						}
				}
				catch (Exception $e){
					die('Erreur: '.$e->getMessage());
				}
		}

		function updatechamps($champ1,$champ2,$champ3,$champ4,$id){
		
			$query = "UPDATE `users` SET 
        `champ1` = '$champ1',
        `champ2` = '$champ2',
        `champ3` = '$champ3',
        `champ4` = '$champ4' 
        WHERE `id` = $id ";
			
			$db = config::getConnexion();
			$statement = $db->prepare($query);
			try{		
				$statement->execute();

						
				}
				catch (Exception $e){
					die('Erreur: '.$e->getMessage());
				}
		}

		function updateback($Username,$email,$password,$champ1,$champ2,$champ3,$champ4,$id){
		
			$query = "UPDATE `users` SET 
        `username` = '$Username',
        `email` = '$email',
        `password` = '$password',
        `champ1` = '$champ1',
        `champ2` = '$champ2',
        `champ3` = '$champ3',
        `champ4` = '$champ4'
        WHERE `id` = $id ";
			
			$db = config::getConnexion();
			$statement = $db->prepare($query);
			try{		
				$statement->execute();

						
				}
				catch (Exception $e){
					die('Erreur: '.$e->getMessage());
				}
		}

		function supprimerUtilisateur($id){
			$sql="DELETE FROM users WHERE id= :id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id',$id);
			try{
				$req->execute();
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}

		function delete_avatar($id){
			$db = config::getConnexion();
			try {	
				$query=$db->prepare("SELECT avatar FROM users  WHERE `id` = $id ");
				$query->execute();
				$res=$query->fetchColumn();
				unlink("../assets/images/$res");
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
            }
		}

		function modifierUtilisateur($Utilisateur, $id, $avatar){
			
				$db = config::getConnexion();
				try {
					$query = $db->prepare(
					'UPDATE users SET 
                        `username` = :username,
                        `pseudo` = :pseudo,
                        `email` = :email,
                        `password` = :password,
                        `rank` = :rank,
                        `acc_type` = :acc_type,
                        `contact` = :contact, 
                        `description` = :description, 
                        `facebook` = :facebook, 
                        `role` = :role
						`avatar` = :avatar
					 WHERE id = :id'
				);
				$query->execute([
                    'username' => $Utilisateur->getUsername(),
                    'pseudo' => $Utilisateur->getpseudo(),
					'email' => $Utilisateur->getemail(),
					'password' => $Utilisateur->getpassword(),
					'rank' => $Utilisateur->getrank(),
					'acc_type' => $Utilisateur->getacc_type(),
					'contact' => $Utilisateur->getcontact(),
					'description' => $Utilisateur->getdescription(),
					'facebook' => $Utilisateur->getfb(),
                    'role' => $Utilisateur->getrole(),
                    `avatar` => $avatar,
					'id' => $id		
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
				// echo $rzlt ."modified". $Utilisateur->getUsername();
				// if($rzlt!=0){
				// 	header("Location:../views/profile.php?id= $id");
				//    }
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

		function recupererUtilisateur($id){
			$sql="SELECT * from users where id=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$user=$query->fetch();
				return $user;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}

		function recupererUtilisateur1($id){
			$sql="SELECT * from users where id=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();
				
				$user = $query->fetch(PDO::FETCH_OBJ);
				return $user;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}

		
		function connexionUser($username,$password){
			$sql="SELECT * FROM users  WHERE `username` = `$username` AND `password` = `$password` ";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();
				$count=$query->rowCount();
				if($count > 0) {
					$x=$query->fetch();
					$message = $x['acc_type'];
					
				} else {
					
					$message = "pseudo ou le mot de passe est incorrect";
				}
			}
			catch (Exception $e){
					$message= " ".$e->getMessage();
			}
		  return $message;
		}

		function get_id($username){
			$res=NULL;
			$db = config::getConnexion();
		
				$query=$db->prepare("SELECT id FROM users  WHERE username = '$username'  ");
				$query->execute();
				$res=$query->fetchColumn();
				if($res > 0) {
					return $res;
				} else {
					echo"Informations incorrect";
					
				}

		}
		
		function authentification($id){
			$db = config::getConnexion();
		
				$query=$db->prepare("SELECT `acc_type` FROM `users` WHERE `id` = $id ");
				$query->execute();
				$res=$query->fetchColumn();
		 
		
			return $res;
		}
	}



?>