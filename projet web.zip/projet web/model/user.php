<?PHP
	class Utilisateur{
		private ?int $id = null;
		private ?string $Username = null;
		private ?string $pseudo = null;
		private ?string $password = null;
		private ?string $email = null;
		private ?string $rank = null;
		private ?string $role = null;
		private ?string $acc_type = null;
		private ?string $contact = null;
		private ?string $champ1= null;
		private ?string $champ2 = null;
		private ?string $champ3  = null;
		private ?string $champ4 = null;
		private ?string $description = null;
		private ?string $fb = null;
		

	function __construct(int $id, string $Username,  string $email, string $pseudo, string $password, string $rank, string $role,string $acc_type,
								 string $contact, string $champ1, string $champ2,string $champ3, string $champ4, string $description, string $fb){
			
			$this->id=$id;						
			$this->Username=$Username;
			$this->pseudo=$pseudo;
			$this->rank=$rank;
			$this->role=$role;
			$this->email=$email;
			$this->acc_type=$acc_type;
			$this->contact=$contact;
			$this->password=$password;
			$this->champ1=$champ1;
			$this->champ2=$champ2;
			$this->champ3=$champ3;
			$this->champ4=$champ4;
			$this->description=$description;
			$this->fb=$fb;
			

		}

		function getId(): int{
			return $this->id;
		}
		function getUsername(): string{
			return $this->Username;
		}
		function getpseudo(): string{
			return $this->pseudo;
		}
		function getEmail(): string{
			return $this->email;
		}
		function getrank(): string{
			return $this->rank;
		}
		function getrole(): string{
			return $this->role;
		}
		function getPassword(): string{
			return $this->password;
		}
		function getacc_type(): string{
			return $this->acc_type;
		}
		function getcontact(): string{
			return $this->contact;
		}
		function getchamp1(): string{
			return $this->champ1;
		}
		function getchamp2(): string{
			return $this->champ2;
		}
		function getchamp3(): string{
			return $this->champ3;
		}
		function getchamp4(): string{
			return $this->champ4;
		}
		function getdescription(): string{
			return $this->description;
		}
		function getfb(): string{
			return $this->fb;
		}

		function setid(int $id): void{
			$this->id=$id;
		}
        function setUsername(string $Username): void{
			$this->Username=$Username;
		}
		function setpseudo(string $pseudo): void{
			$this->pseudo=$pseudo;
		}
		function setrank(string $rank): void{
			$this->rank=$rank;
		}
		function setEmail(string $email): void{
			$this->email=$email;
		}
		function setPassword(string $password): void{
			$this->password=$password;
		}
		function setrole(string $role): void{
			$this->role=$role;
		}
		function setacc_type(string $acc_type): void{
			$this->acc_type=$acc_type;
		}
		function setcontact(string $contact): void{
			$this->contact=$contact;
		}
		function setchamp1(string $champ1): void{
			$this->champ1=$champ1;
		}
		function setchamp2(string $champ2): void{
			$this->champ2=$champ2;
		}
		function setchamp3(string $champ3): void{
			$this->champ3=$champ3;
		}
		function setchamp4(string $champ4): void{
			$this->champ4=$champ4;
		}
		function setdescription(string $description): void{
			$this->description=$description;
		}
		function setfb(string $fb): void{
			$this->fb=$fb;
		}

	}
?>