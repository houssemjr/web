$(function() {
    $("form[name='login']").validate({
      rules: {
        
        uname: {
          required: true
        },
        psw: {
          required: true,
          
        }
      },
       messages: {
        required: "Please enter Username",
       
        psw: {
          required: "Please enter pasword",
         
        }
        
      },
      submitHandler: function(form) {
        form.submit();
      }
    });
  });
  


$(function() {

$("form[name='registration']").validate({
rules: {
Username: "required",
rank: "required",
role: "required",
d1: "required",
fb: "required",
champ1: "required",
champ1: "required",
champ1: "required",
champ1: "required",
c1: "required",
email: {
 required: true,
 email: true
},
password: {
 required: true,
 minlength: 5
}
},

messages: {
Username: "Please enter your username",
rank: "Please enter your rankus",
role: "Please enter your role",
d1: "Please enter your description",
fb: "Please enter your facebook",
champ1: "Please enter your chamlpion 1",
champ1: "Please enter your champion 2",
champ1: "Please enter your champion 3",
champ1: "Please enter your champion 4",
c1: "Please enter your contact",
password: {
 required: "Please provide a psw",
 minlength: "Your psw must be at least 5 characters long"
},
email: "Please enter a valid email address"
},

submitHandler: function(form) {
form.submit();
}
});
});