<?php 
include_once '../model/user.php';
include_once '../controller/userC.php';  
$userC = new UtilisateurC();
   $error = "";
   $id=$_GET['id'];
try {
    if(isset($_POST['update']))
    {
        
        if (
         isset($_POST['Username']) &&
         isset($_POST['email']) &&
         isset($_POST['password']) &&
         isset($_POST['pseudo']) &&
         isset($_POST['rank']) &&
         isset($_POST['role']) &&
         isset($_POST['acc_type']) && 
         isset($_POST['contact']) &&
         isset($_POST['description']) && 
         isset($_POST['facebook']) 
      )
      {
          if (
            !empty($_POST['Username']) &&
            !empty($_POST['email']) &&
            !empty($_POST['password']) &&
            !empty($_POST['rank']) &&
            !empty($_POST['role']) &&
            !empty($_POST['acc_type']) &&
            !empty($_POST['contact']) &&
            !empty($_POST['description']) &&
            !empty($_POST['facebook'])
        ){
         $old_user=$userC->recupererUtilisateur($id);

         $user = new Utilisateur(
            $id,
            $_POST['Username'],
            $_POST['email'],
            $_POST['pseudo'],
            $_POST['password'],
            $_POST['rank'],
            $_POST['role'],
            $_POST['acc_type'],
            $_POST['contact'],
            $old_user['champ1'],
            $old_user['champ2'],
            $old_user['champ3'],
            $old_user['champ4'],
            $_POST['description'],
              $_POST['facebook']
          );
            
         }
         else
            echo $error = "Missing information";
            
        }
      
    if(isset($_FILES['avatar']) AND !empty($_FILES['avatar']['name'])) {
       $tailleMax = 2097152;
       $extensionsValides = array('jpg', 'jpeg', 'gif', 'png');
       if($_FILES['avatar']['size'] <= $tailleMax) {
          $extensionUpload = strtolower(substr(strrchr($_FILES['avatar']['name'], '.'), 1));
          if(in_array($extensionUpload, $extensionsValides)) {
             $chemin = "../assets/images/".$id.".".$extensionUpload;
             $resultat = move_uploaded_file($_FILES['avatar']['tmp_name'], $chemin);
             if($resultat) {
                    $avatar=$id.'.'.$extensionUpload;

                    $userC->modifierUtilisateur($user,$id,$avatar);
                    header("Location:../views/profile.php?id= $id");
                 } else {                    
                    echo '<script> alert("Erreur durant limportation de votre photo de profil"); </script>';
                 }
              } else {                
                 echo '<script> alert("Votre photo de profil doit être au format jpg, jpeg, gif ou png"); </script>';
              }
           } else {
              echo '<script> alert("votre photo de profil ne doit pas dépasser 2Mo"); </script>';
           }
        }
          
        
    }
    
}
catch (Exception $e) {
    $e->getMessage();
}
?>