<?php
include_once '../model/user.php';
include_once '../controller/userC.php';

$error = "";

// create user
$user = null;
$rand_id=rand(1, 999999);	
// create an instance of the controller
$userC = new UtilisateurC();
if (
   isset($_POST['Username']) &&
   isset($_POST['email']) &&
   isset($_POST['password']) &&
   isset($_POST['pseudo']) &&
   isset($_POST['rank']) &&
   isset($_POST['role']) &&
   isset($_POST['coach/player']) && 
   isset($_POST['c1']) &&
   isset($_POST['champ1']) && 
   isset($_POST['champ2']) &&
   isset($_POST['champ3']) &&
   isset($_POST['champ4']) && 
   isset($_POST['d1']) && 
   isset($_POST['fb']) 
)
{
    if (
      !empty($_POST['Username']) &&
      !empty($_POST['email']) &&
      !empty($_POST['password']) &&
      !empty($_POST['rank']) &&
      !empty($_POST['role']) &&
      !empty($_POST['coach/player']) &&
      !empty($_POST['c1']) &&
      !empty($_POST['champ1']) &&
      !empty($_POST['champ2']) &&
      !empty($_POST['champ3']) &&
      !empty($_POST['champ4']) &&
      !empty($_POST['d1']) &&
      !empty($_POST['fb'])
  ){
      $user = new Utilisateur(
        $rand_id,
        $_POST['Username'],
        $_POST['email'],
        $_POST['pseudo'],
        $_POST['password'],
        $_POST['rank'],
        $_POST['role'],
        $_POST['coach/player'],
        $_POST['c1'],
        $_POST['champ1'],
        $_POST['champ2'],
        $_POST['champ3'],
        $_POST['champ4'],
        $_POST['d1'],
          $_POST['fb']
      );
      $userC->ajouterUtilisateur($user);
      echo "user added successfully";
  }
  else
$error = "Missing information";
}


?>
<Html lang="en">
    <head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
        <link href="../assets/css/styles.css" rel="stylesheet" >
    <title>SIGN UP</title>
    </head>

<body>

<style>
 body  {
  background-image: url("../assets/images/signup.jpg");
}
</style> 
<div class="container">
<div class="row">
        <div class="myform form ">
                        <div class="logo mb-3">
                           <div class="col-md-12 text-center">
                              <h1 >Signup<?php echo $error; ?></h1>
                           </div>
                        </div>
                      <form action="#" name="registration" methode="post">
                           <div class="form-group">
                              <label >Username</label>
                              <input type="text"  name="Username" class="form-control" id="Username"  placeholder="Enter Username" required>
                           </div>
                          <div class="form-group">
                              <label >Email address</label>
                              <input type="email" name="email"  class="form-control" id="email"  placeholder="Enter email" required>
                           </div>
                           <div class="form-group">
                              <label >Password</label>
                              <input type="password" name="password" id="password"  class="form-control" placeholder="Enter Password" required>
                           </div> 
                           <div class="form-group">
                              <label >Pseudo</label>
                              <input type="text"  name="Pseudo" class="form-control" id="Pseudo"  placeholder="Enter Pseudo" required >
                           </div>
                           <div class="form-group">
                              <label >Rank</label>
                              <input type="text"  name="rank" class="form-control" id="rank"  placeholder="Enter Rank" required >
                           </div>
                           <div class="form-group">
                              <label >Role</label>
                              <input type="text"  name="role" class="form-control" id="role"  placeholder="Enter Role" required>
                           </div>
                           <div class="form-group">
                              <label >Coach / Player</label>
                              <input type="text"  name="coach/player" class="form-control" id="coach/player" placeholder="Enter Coach / Player" required>
                           </div>
                           <div class="form-group">
                              <label >Main Champion</label>
                              <input type="text"  name="champ1" class="form-control" id="champ1" placeholder="Enter Main Champion" required>
                           </div>
                           <div class="form-group">
                              <label >Second Champion</label>
                              <input type="text"  name="champ2" class="form-control" id="champ2" placeholder="Enter Second Champion" required>
                           </div>
                           <div class="form-group">
                              <label >Third Champion</label>
                              <input type="text"  name="champ3" class="form-control" id="champ3"  placeholder="Enter Third Champio" required>
                           </div>
                           <div class="form-group">
                              <label >Fourh Champion</label>
                              <input type="text"  name="champ4" class="form-control" id="champ4"  placeholder="Enter Fourh Champion" required>
                           </div>
                           <div class="form-group">
                              <label >Descriptiond</label>
                              <input type="text"  name="d1" class="form-control" id="d1"  placeholder="Enter Descriptiond" required>
                           </div>
                           <div class="form-group">
                              <label >Contact</label>
                              <input type="text"  name="c1" class="form-control" id="c1"  placeholder="Enter Contact" required>
                           </div>
                           <div class="form-group">
                              <label >Facebook</label>
                              <input type="text"  name="fb" class="form-control" id="fb"  placeholder="Enter Facebook" required>
                           </div>
                           
                           
                              <button type="submit" class=" btn btn-block mybtn btn-primary tx-tfm">Get Started For Free</button>
                          
                           <div class="col-md-12 ">
                              <div class="form-group">
                                 <p class="text-center"><a href="sign_in.php" id="signin">Already have an account?</a></p>
                              </div>
                           </div>
                            </div>
                        </form>
                     </div>
                     </div>
                     </div>                
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="../assets/js/sign_in_up_control.js"></script>


</body>
</Html>