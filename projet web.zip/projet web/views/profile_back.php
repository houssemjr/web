<?php
		include_once '../controller/userC.php';			
		$userC=new UtilisateurC();
		$listeUsers=$userC->profile($_GET['id']);
				
					foreach ($listeUsers as $row) { 
					?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>LOLproTN</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">

	<!-- stylesheet css -->
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="../assets/css/templatemo-gray.css">
	<link rel="stylesheet" href="../assets/css/modal-pop-up.css">
</head>
<body data-spy="scroll" data-target=".navbar-collapse">
<style>
 body  {
  background-image: url("../assets/images/tm-bg-slide-1.jpg");
}
</style> 


<!-- preloader section -->
<div class="preloader">
	<div class="sk-spinner sk-spinner-wordpress">
       <span class="sk-inner-circle"></span>
     </div>
</div>
						
				
<!-- header section -->
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">			
				<?php	if($row['avatar']!=NULL)
						{
				?>	
				<img  class="img-responsive img-circle tm-border" alt="templatemo easy profile" src="../assets/images/<?php echo $row['avatar']; } else{ ?>">
					<img src="../assets/images/<?php echo "league-client-update-header.jpg"; }?>" class="img-responsive img-circle tm-border" alt="templatemo easy profile">	
					
				<hr>
				<h1 class="tm-title bold shadow"><?php echo $row['pseudo']; ?></h1>	
				<h1 class="white bold shadow"><?php echo $row['acc_type']; ?></h1>
			</div>
		</div>

</header>

<!-- about and skills section -->

<section class="container">
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<div class="about" data-transition="fromTop">
				<h2 class="accent">Main role</h2>
				<h3><?php echo $row['role']; ?></h3>
				<h2 class="accent">Rank in-game</h2>
				<h3><?php echo $row['rank']; ?></h3>
			</div>
		</div>
		<div class="col-md-6 col-sm-12">
			<div class="skills">
				<h2 class="white">Skills</h2>
				<strong>SUPP</strong>
				<span class="pull-right">70%</span>
					<div class="progress">
						<div class="progress-bar progress-bar-primary" role="progressbar"
                        aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%;"></div>
					</div>
				<strong>ADC</strong>
				<span class="pull-right">85%</span>
					<div class="progress">
						<div class="progress-bar progress-bar-primary" role="progressbar"
                        aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 85%;"></div>
					</div>
				<strong>Mid lane</strong>
				<span class="pull-right">95%</span>
					<div class="progress">
						<div class="progress-bar progress-bar-primary" role="progressbar"
                        aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width: 95%;"></div>
					</div>
			</div>
		</div>
	</div>
</section>

<!-- education and languages -->
<section class="container">
	<div class="row">
		<div class="col-md-8 col-sm-12">
			<div class="education">
				<h2 class="white">Description</h2>
					<div class="education-content">
						<h4 class="education-title accent">More about me ?</h4>
						<p class="education-description"><?php echo $row['description']; ?></p>
					</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-12">
					
			<div class="languages">
			
				<h2>Champion pool</h2>
				
					<ul>
						<li><?php echo $row['champ1']; ?></li>
						<li><?php echo $row['champ2']; ?></li>
						<li><?php echo $row['champ3']; ?></li>
						<li><?php echo $row['champ4']; ?></li>
					</ul>
					
			</div>
		</div>
	</div>
</section>

<!-- contact and experience -->
<section class="container">
	<div class="row">
		<div class="col-md-4 col-sm-12">
			<div class="contact">
				<h2>Contact</h2>
					<p><i class="fa fa-facebook"></i> <?php echo $row['facebook'];?></p>
					<p><i class="fa fa-phone"></i><?php echo $row['contact']; ?></p>
					<p><i class="fa fa-envelope"></i> <?php echo $row['email']; ?></p>
					<!--<p><i class="fa fa-discord"></i> discord</p>-->

			</div>

		</div>
		<?php	
					}
				
				?>
		<br>

		<div class="col-md-4 col-sm-12">

<iframe width="560" height="315" src="https://www.youtube.com/embed/hta3YUsWb1U" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="vid"></iframe>
		</div>
	</div>
</section>



<!-- footer section -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<p class="Paragraph">Copyright &copy; <sup class="suppart">2020</sup> LOLproTN</p>
				<ul class="social-icons">
					<li><a href="https://www.facebook.com"target="_blank" class="fa fa-facebook"></a></li>
          <li><a href="https://www.gmail.com" target="_blank"class="fa fa-google-plus"></a></li>
					<li><a href="https://www.twitter.com" target="_blank"class="fa fa-twitter"></a></li>
					<li><a href="https://dribbble.com/"target="_blank" class="fa fa-dribbble"></a></li>
					<li><a href="https://github.com/" target="_blank"class="fa fa-github"></a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>


<!-- javascript js -->
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/jquery.backstretch.min.js"></script>
<script src="../assets/js/custom.js"></script>


</body>
</html>
