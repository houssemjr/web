<?php 
include_once '../model/user.php';
include_once '../controller/userC.php';  
$userC = new UtilisateurC();
   $error = "";
   $id=$_GET['id'];
try {
    if(isset($_POST['update']))
    {
        if(
            isset($_POST['Username']) && 
            isset($_POST['email']) &&
            isset($_POST['password']) && 
            isset($_POST['champ1']) && 
            isset($_POST['champ2']) &&
            isset($_POST['champ3']) && 
            isset($_POST['champ4']) 
        ){
            if (
                !empty($_POST['Username']) &&
                !empty($_POST['email']) &&
                !empty($_POST['password']) &&
                !empty($_POST['champ1']) &&
                !empty($_POST['champ2']) &&
                !empty($_POST['champ3']) &&
                !empty($_POST['champ4'])
            ){

                $userC->updateback($_POST['Username'],$_POST['email'],$_POST['password'],$_POST['champ1'],$_POST['champ2'],$_POST['champ3'],$_POST['champ4'],$id);
                header('Location:table.php');
                 echo '<script> alert("UPDATED SUCCESSFULLY"); </script>';
            }
            else
            echo $error = "Missing information";
   
    }
    
}
}
catch (Exception $e) {
    $e->getMessage();
}
?>