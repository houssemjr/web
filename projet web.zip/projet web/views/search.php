<?php
include_once '../controller/userC.php';	
         $utilisateurC=new UtilisateurC();
         $listeUsers=$utilisateurC->afficherUtilisateurs();
         
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>search</title>
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">

  <!-- stylesheet css -->
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="../assets/css/templatemo-gray.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.css"/>
</head>
<body data-spy="scroll" data-target=".navbar-collapse">
<style>
 body  {
   background-image: url("../assets/images/tm-bg-slide-2.jpg");
  color: #d12546;
}
</style> 
  <nav class="nav-bar ">

    <ul>
      <li> <a href="#">Home</a> </li>
      <li> <a href="profile.php">Profile</a> </li>
      <li> <a href="#">Forum</a> </li>
      <li> <a href="search.php" class="active">Search</a> </li>
    </ul>
    <div class="loginPart">
      <button type="button" name="button" class="btn-grad ">Sign out</button>
    </div>
  </nav>
<!-- preloader section -->
<div class="preloader">
  <div class="sk-spinner sk-spinner-wordpress">
       <span class="sk-inner-circle"></span>
     </div>
</div>
            
        
<!-- header section -->
<header>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12">

        <img src="../assets/images/league-client-update-header.jpg" class="img-responsive img-circle tm-border" alt="templatemo easy profile">
        
        <hr>
    
      </div>
    </div>

  </div>
 

</header>



<table id="datatableid" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Nickame</th>
                <th>Coach/Player</th>
                <th>Rank</th>
                <th>Main role</th>
                <th>Main champion</th>
                <th>      </th>
            </tr>
        </thead>
        
     <?php 
      foreach ($listeUsers as $row) { 
     ?>
        <tbody>
          
            <tr>
                <td><?php echo $row['pseudo']; ?></td>
                <td><?php echo $row['acc_type']; ?></td>
                <td><?php echo $row['rank']; ?></td>
                <td><?php echo $row['role']; ?></td>
                <td><?php echo $row['champ1']; ?></td>
                <td><BUTTON type="button" name="edit"class="btn-grad"><a href="profile.php?id=<?php echo $row['id']; ?>"> VIEW</BUTTON></td>
            </tr>
            
        </tbody>
        <?php 
          }

        ?>

    </table>

    
<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12">
        <p class="Paragraph">Copyright &copy; <sup class="suppart">2020</sup> LOLproTN</p>
        <ul class="social-icons">
          <li><a href="https://www.facebook.com"target="_blank" class="fa fa-facebook"></a></li>
          <li><a href="https://www.gmail.com" target="_blank"class="fa fa-google-plus"></a></li>
          <li><a href="https://www.twitter.com" target="_blank"class="fa fa-twitter"></a></li>
          <li><a href="https://dribbble.com/"target="_blank" class="fa fa-dribbble"></a></li>
          <li><a href="https://github.com/" target="_blank"class="fa fa-github"></a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>

<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/jquery.backstretch.min.js"></script>
<script src="../assets/js/custom.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.js"></script>


<script>
  $(document).ready( function () {
      $('#datatableid').DataTable();
    } );
</script>

</body>
</html>
