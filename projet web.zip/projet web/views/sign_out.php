<?php
session_start();
session_destroy();
// header('Location:acceuil.php');
echo '<script> alert("You signed out"); </script>';
?>


    