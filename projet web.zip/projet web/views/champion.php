<?php 
include_once '../model/user.php';
include_once '../controller/userC.php';  
$userC = new UtilisateurC();
   $error = "";
   $id=$_GET['id'];

try {
    if(isset($_POST['champ_update']))
    {
        if(
            isset($_POST['champ1']) && 
         isset($_POST['champ2']) &&
         isset($_POST['champ3']) && 
         isset($_POST['champ4']) 
        ){
            if (
                !empty($_POST['champ1']) &&
                !empty($_POST['champ2']) &&
                !empty($_POST['champ3']) &&
                !empty($_POST['champ4'])
            ){

                $userC->updatechamps($_POST['champ1'],$_POST['champ2'],$_POST['champ3'],$_POST['champ4'],$id);
                header("Location:../views/profile.php?id= $id");
                echo '<script> alert("UPDATED SUCCESSFULLY"); </script>';
            }
            else
            echo $error = "Missing information";
            
            
        }
    }
    
}
catch (Exception $e) {
    $e->getMessage();
}
?>