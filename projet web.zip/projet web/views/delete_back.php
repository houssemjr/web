<?php
include '../controller/userC.php'; 
$userC=new UtilisateurC();
	
if (isset($_POST["id_del"])){
	$userC->supprimerUtilisateur($_POST["id_del"]);
	$userC->delete_avatar($_POST["id_del"]);
	header('Location:table.php');
}

?>