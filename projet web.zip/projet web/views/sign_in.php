<?php
include_once '../model/user.php';
include_once '../controller/userC.php';
session_start();
$message="";
$acc_type="";
$userC = new UtilisateurC();
if (isset($_POST["login"])) {
    if (isset($_POST["uname"]) &&
        isset($_POST["psw"])) {
        if (!empty($_POST["uname"]) &&
            !empty($_POST["psw"]))
          {   
            $message=$userC->connexionUser($_POST["uname"],$_POST["psw"]);
            $id=$userC->get_id($_POST["uname"]);
            $acc_type=$userC->authentification($id);

            $_SESSION['e'] = $_POST["uname"];// on stocke dans le tableau une colonne ayant comme nom "e",
            //  avec l'email à l'intérieur
            echo '<script> alert("$message"); </script>';
            if($message!='pseudo ou le mot de passe est incorrect' && $acc_type!='admin'){
              if(isset($_POST["remember"]))   
                  {  
                    setcookie ("member_login",$_POST["uname"],time()+ (10 * 365 * 24 * 60 * 60));  
                    setcookie ("member_password",$_POST["psw"],time()+ (10 * 365 * 24 * 60 * 60));
                  }  
                  else  
                  {  
                    if(isset($_COOKIE["member_login"]))   
                    {  
                    setcookie ("member_login","");  
                    }  
                    if(isset($_COOKIE["member_password"]))   
                    {  
                    setcookie ("member_password","");  
                    }  
                  }
              header("Location:profile.php?id=$id");
            }
            elseif($message!='pseudo ou le mot de passe est incorrect' && $acc_type=='admin'){
              header("Location:table.php");
            }
            else{
                $message='pseudo ou le mot de passe est incorrect';
            }
          }
        else
            $message = "Missing information";}
    }
    ?>

<Html lang="en">
    <head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
        <link href="../assets/css/styles.css" rel="stylesheet" >
        <title>Authentification</title>
    </head>
    
<body>
<style>
 body  {
  background-image: url("../assets/images/signin.jpg");
}
</style> 
    <div class="container">
        <div class="row">
		  <div class="col-md-5 mx-auto">
			 <div id="first">
				<div class="myform form ">
					 <div class="logo mb-3">
						 <div class="col-md-12 text-center">
							<h1>Login<?php if($message!="") { echo $message.$_COOKIE['member_password']; } ?></h1>
						 </div>
					</div>
                   <form action="" method="post" name="login">
                    
                           <div class="form-group">
                              <label for="exampleInputEmail1">Username </label>
                              <input type="text" name="uname"  class="form-control" id="uname" aria-describedby="emailHelp" placeholder="Enter Username"  value="<?php if(isset($_COOKIE['member_login'])) { echo $_COOKIE['member_login']; } ?>">
                           </div>
                           <div class="form-group">
                              <label for="exampleInputEmail1">Password</label>
                              <input type="password" name="psw" id="psw"  class="form-control" aria-describedby="emailHelp" placeholder="Enter Password" value="<?php if(isset($_COOKIE['member_password'])) { echo $_COOKIE['member_password']; } ?>">
                           </div>
                           <div class="form-group">
                           <label>
                                <input type="checkbox"  name="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?>> Remember me
                              </label>
                           </div>
                           <div class="col-md-12 text-center ">
                              <button type="submit" name="login" class=" btn btn-block mybtn btn-primary tx-tfm">Login</button>
                           </div>
                           <div class="col-md-12 ">
                              <div class="login-or">
                                 <hr class="hr-or"> 
                           <div class="form-group">
                              <p class="text-center">Don't have account? <a href="sign_up.php" id="signup">Sign up here</a></p>
                           </div>
                        </form>
                 
				</div>
			</div>
			  
      </div>   
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="../assets/js/sign_in_up_control.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>       
</body> 
</Html>
