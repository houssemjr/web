<Html lang="en">
    <head>
    <title>SIGN UP</title>
    </head>

<body>
    <form method="POST" action="formulaire.php">
    
    <input class="text" type="text" name="Username" placeholder="Username" required=""><br>
                <br>
                <input class="text email" type="email" name="email" placeholder="Email" required=""><br><br>
                <input class="text" type="password" name="password" placeholder="Password" required=""><br><br>

                <input class="text" type="text" name="pseudo" placeholder="pseudo" required=""><br><br>

                <input class="text" type="text" name="rank" placeholder="rank" required=""><br><br>

                <input class="text" type="text" name="role" placeholder="role" required=""><br><br>

               <input class="text" type="text" name="coach/player" placeholder="coach/player" required=""><br><br>
               
                 <input class="text" type="text" name="c1" placeholder="contact" required=""><br><br>
               
               <input class="text" type="text" name="champ1" placeholder="champion 1" required=""><br><br>
                <input class="text" type="text" name="champ2" placeholder="champion 2" required=""><br><br>
               
                <input class="text" type="text" name="champ3" placeholder="champion 3" required=""><br><br>
               
                <input class="text" type="text" name="champ4" placeholder="champion 4" required=""><br><br>
                <input class="text" type="text" name="d1" placeholder="Description" required=""><br><br>
                <input class="text" type="text" name="fb" placeholder="Facebook" required=""><br><br>

    <button type="submit">sign up</button>
    </form>

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</body>
</Html>
