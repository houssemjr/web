<?php
function connexionUser($username,$password){
    $sql="SELECT * FROM users  WHERE `username` = `$username` , `password` = `$password` ";
    $uname = 'root';
    $pass = '';
    $connection = new PDO( 'mysql:host=localhost;dbname=projet web',$uname, $pass );
    try{
        $query=$connection->prepare($sql);
        $query->execute();
        $count=$query->rowCount();
        if($count==0) {
            $message = "pseudo ou le mot de passe est incorrect";
        } else {
            $x=$query->fetch();
            $message = $x['acc_type'];

        }
    }
    catch (Exception $e){
            $message= " ".$e->getMessage();
    }
  return $message;
}

function get_id($username){
    $uname = 'root';
    $pass = '';
    $connection = new PDO( 'mysql:host=localhost;dbname=projet web',$uname, $pass );

        $query=$connection->prepare("SELECT id FROM users  WHERE `username` = '$username' ");
        $query->execute();
        $res=$query->fetchColumn();


    return $res;
    
}

function authentification($id){
    $uname = 'root';
    $pass = '';
    $connection = new PDO( 'mysql:host=localhost;dbname=projet web',$uname, $pass );

        $query=$connection->prepare("SELECT `acc_type` FROM `users` WHERE `id` = $id ");
        $query->execute();
        $res=$query->fetchColumn();
 

    return $res;
}

?>