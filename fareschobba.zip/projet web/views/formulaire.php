<?php
$Username = $_POST['Username'];
$email = $_POST['email'];
$password = $_POST['password'];
$pseudo = $_POST['pseudo'];
$rank = $_POST['rank'];
$role = $_POST['role'];
$acc_type = $_POST['coach/player']; 
$contact = $_POST['c1']; 
$champ1 = $_POST['champ1']; 
$champ2 = $_POST['champ2'];
$champ3 = $_POST['champ3']; 
$champ4 = $_POST['champ4']; 
$description = $_POST['d1']; 
$fb = $_POST['fb'];

	$uname = 'root';
    $pass = '';
    $connection = new PDO( 'mysql:host=localhost;dbname=projet web',$uname, $pass );
$rand_id=rand(1, 999999);	
$sql ="INSERT INTO users (id,username,email,password,pseudo,rank,role,acc_type,contact,champ1,champ2,champ3,champ4,description,facebook) 
VALUES ('$rand_id','$Username','$email','$password','$pseudo','$rank','$role','$acc_type','$contact','$champ1','$champ2','$champ3','$champ4','$description','$fb')" ;

try{
	$query = $connection->prepare($sql);

	$query->execute();
	echo "user added successfully";
}
catch (Exception $e){
	echo 'Erreur: '.$e->getMessage();
}

?>