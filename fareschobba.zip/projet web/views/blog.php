<?php
	$username = 'root';
	$password = '';
	$connection = new PDO( 'mysql:host=localhost;dbname=projet web', $username, $password );

	$id=$_GET['id'];

	$query=$connection->prepare("SELECT acc_type FROM users  WHERE `id` = $id ");
        $query->execute();
        $res=$query->fetchColumn();

        if(strtolower($res)=="coach"){
        	echo '<script> alert("BLOG COACH view"); </script>';	
        }
        else{
        	echo '<script> alert("BLOG PLAYER view"); </script>';
        }


?>