<?php
$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=projet web', $username, $password );    

$id=$_GET['id'];

$sql="DELETE FROM users WHERE id= $id";

			$req=$connection->prepare($sql);
			$req->bindValue(':id',$id);
			try{
                if(isset($_POST['supr']))
                {
				$req->execute();
				header('Location:table.php');
                }
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
            }
?>