<?php 
$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=projet web', $username, $password );    
try {
    if(isset($_POST['update']))
    {
        $id=$_GET['id'];
    $Username = $_POST['Username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $champ1 = $_POST['champ1'];
    $champ2 = $_POST['champ2'];
    $champ3 = $_POST['champ3'];
    $champ4 = $_POST['champ4']; 




        $query = "UPDATE `users` SET 
        `username` = '$Username',
        `email` = '$email',
        `password` = '$password',
        `champ1` = '$champ1',
        `champ2` = '$champ2',
        `champ3` = '$champ3',
        `champ4` = '$champ4'
        WHERE `id` = $id ";

        $statement = $connection->prepare($query);
          $statement->execute();
          $result = $statement->rowCount();

          header('Location:table.php');
          echo '<script> alert("UPDATED SUCCESSFULLY"); </script>';
          
        
    }
    
}
catch (Exception $e) {
    $e->getMessage();
}
?>