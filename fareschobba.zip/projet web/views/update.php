<?php 
$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=projet web', $username, $password );    
try {
    if(isset($_POST['update']))
    {
        $id=$_GET['id'];
    $Username = $_POST['Username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $pseudo = $_POST['pseudo'];
    $rank = $_POST['rank'];
    $role = $_POST['role'];
    $acc_type = $_POST['acc_type']; 
    $contact = $_POST['contact'];  
    $description = $_POST['description']; 
    $facebook = $_POST['facebook']; 

    if(isset($_FILES['avatar']) AND !empty($_FILES['avatar']['name'])) {
       $tailleMax = 2097152;
       $extensionsValides = array('jpg', 'jpeg', 'gif', 'png');
       if($_FILES['avatar']['size'] <= $tailleMax) {
          $extensionUpload = strtolower(substr(strrchr($_FILES['avatar']['name'], '.'), 1));
          if(in_array($extensionUpload, $extensionsValides)) {
             $chemin = "../ressources/images/".$id.".".$extensionUpload;
             $resultat = move_uploaded_file($_FILES['avatar']['tmp_name'], $chemin);
             if($resultat) {
                    $avatar=$id.'.'.$extensionUpload;
                    $query = "UPDATE `users` SET 
                    `username` = '$Username',
                    `email` = '$email',
                    `password` = '$password',
                    `pseudo` = '$pseudo',
                    `rank` = '$rank',
                    `acc_type` = '$acc_type',
                    `contact` = '$contact', 
                    `description` ='$description', 
                    `facebook` ='$facebook', 
                    `role` ='$role',
                    `avatar` = '$avatar'
                    WHERE `id` = $id ";

                      $statement = $connection->prepare($query);
                      $statement->execute();
                      $result = $statement->rowCount();

                      header("Location:profile.php?id= $id");
        
                 } else {                    
                    echo '<script> alert("Erreur durant limportation de votre photo de profil"); </script>';
                 }
              } else {                
                 echo '<script> alert("Votre photo de profil doit être au format jpg, jpeg, gif ou png"); </script>';
              }
           } else {
              echo '<script> alert("otre photo de profil ne doit pas dépasser 2Mo"); </script>';
           }
        }
          
        
    }
    
}
catch (Exception $e) {
    $e->getMessage();
}
?>