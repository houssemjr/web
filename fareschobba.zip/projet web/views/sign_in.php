<?php
session_start();
include_once 'session.php';
$message="";
$acc_type="";
if (isset($_POST["uname"]) &&
    isset($_POST["psw"])) {
    if (!empty($_POST["uname"]) &&
        !empty($_POST["psw"]))
    {   
        $message=connexionUser($_POST["uname"],$_POST["psw"]);
        $id=get_id($_POST["uname"]);
         $acc_type=authentification($id);

         $_SESSION['e'] = $_POST["uname"];// on stocke dans le tableau une colonne ayant comme nom "e",
        //  avec l'email à l'intérieur
        
        if($message!='pseudo ou le mot de passe est incorrect' && $acc_type!='admin'){
          if(isset($_POST["remember"]))   
               {  
                setcookie ("member_login",$username,time()+ (10 * 365 * 24 * 60 * 60));  
                setcookie ("member_password",$password,time()+ (10 * 365 * 24 * 60 * 60));
;
               }  
               else  
               {  
                if(isset($_COOKIE["member_login"]))   
                {  
                 setcookie ("member_login","");  
                }  
                if(isset($_COOKIE["member_password"]))   
                {  
                 setcookie ("member_password","");  
                }  
               }
           header("Location:profile.php?id=$id");
        }
        elseif($message!='pseudo ou le mot de passe est incorrect' && $acc_type=='admin'){
          header("Location:table.php");
        }
        else{
            $message='pseudo ou le mot de passe est incorrect';
        }}
    else
        $message = "Missing information";}
?>

<Html lang="en">
    <head>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" >
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" >
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../assets/css/styles.css" rel="stylesheet" >
        <title>Authentification</title>
    </head>

    <body>
        <form action="" method="POST">
            <div class="imgcontainer">
                </div>
                <?php if($message!="") { echo $message.$_COOKIE['member_password']; } ?>
            <div class="container"><br><br>
              <label for="uname"><b>Username</b></label>
              <input type="text" placeholder="Enter Username" name="uname" value="<?php if(isset($_COOKIE['member_login'])) { echo $_COOKIE['member_login']; } ?>" required ><br><br>
          
              <label for="psw"><b>Password</b></label>
              <input type="password" placeholder="Enter Password" name="psw" value="<?php if(isset($_COOKIE['member_password'])) { echo $_COOKIE['member_password']; } ?>" required><br><br>
          
              <button type="submit">Login</button><br><br>
              <label>
                <input type="checkbox"  name="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?>> Remember me
              </label>
            </div>
          
              <span class="psw">Forgot password ? <a href="#">password?</a></span>
            </div>
          </form> 
    </body>
</Html>
